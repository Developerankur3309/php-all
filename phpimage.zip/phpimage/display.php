<?php
session_start();
 echo "welcome".$_SESSION['user'] 

<h1>Welcome Ankur singh to your page</h1>

