<?php 
$dbhost = "localhost";
$dbuser = "root"; 
$dbpass = ""
$dbname = "login"

$conn = mysqli_connect($dbhost,$dbuser,$dbpass);
if( !$conn)
{
die('could not connect:'.mysqli_error());
}
mysqli_select_db($conn,$dbname);

?>