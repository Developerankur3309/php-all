<?php
session_start();
$con = mysqli_connect("localhost","root","","phpbasic");

if(isset($_POST['save']))
{
 $name = $_POST['name'];
 $time = $_POST['timeof'];
 
 $sql = "insert into time(name,timeof) values('$name','$time')";
 $run = mysqli_query($con, $sql);
 
 if($run)
 {
 $_SESSION['status']= "Inserted Into database";
 header('Location: time.php');
 }
 else
 {
 $_SESSION[]= "Inserted  NotInto database";
 header('Location: time.php');
 
 }
 }
 ?>