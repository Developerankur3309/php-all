<?php
session_start();

$conn = mysqli_connect("localhost","root","","phpbasic");

if(isset($_POST['save']))
{
 $name = $_POST['name'];
 $phone = $_POST['phone'];
 $email = $_POST['email'];
 $deg = $_POST['deg'];
 
 
 $query = "INSERT INTO employe(name,email,phone,deg) VALUES('$name','$phone','$email','$deg') ";
 $run = mysqli_query($conn, $query);
 
 // if($run)
 // {
   // $_SESSION['status'] = "INserted Successfully";
   // header("Location:insert.php");
 
 // }
 // else
 // {
  // $_SESSION['status'] = " Not INserted Successfully";
   // header("Location: insert.php");
 
 // }
// }


//sweethert code  12/02/22

if($run)
 {
   $_SESSION['status'] = "Booking Confirm successfully We will Contacted you";
   $_SESSION['status_code'] = "success";
   header("Location:insert.php");
 
}
  else
  {
 $_SESSION['status'] = " Not Register Successfully";
   $_SESSION['status_code'] = "error";
   header("Location: insert.php");
 
  }
 }

?>