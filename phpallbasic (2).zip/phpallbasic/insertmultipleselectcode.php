<?php
session_start();
$con = mysqli_connect("localhost","root","","phpbasic"); 

if(isset($_POST['submit']))
{
$name = $_POST['name'];
$phone = $_POST['phone'];

foreach($name as $index => $names)
{
//echo $names."-".$phone[$index]; check data
$name = $names;
$phone = $phone[$index];
//$_otherfield = $empid[$index];

$query = "INSERT INTO multipleselectdata (name,phone) VALUES('$name','$phone')";
$run = mysqli_query($con, $query);
}
if($run)
{
 $_SESSION['status'] = 'Multiple Data Inserted Successfully';
 header('Location:insertmultipleselect.php');
 exit(0);
}
 else
 {
 $_SESSION['status'] = "Data Not Inserted";
 header('Location: insertmultipleselect.php');
 exit(0);
 }
}
 
 