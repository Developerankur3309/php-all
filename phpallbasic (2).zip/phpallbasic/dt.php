<?php
session_start();
$con = mysqli_connect("localhost","root","","phpbasic");

if(isset($_POST['save']))
{
 $name = $_POST['name'];
 $dt = $_POST['dt'];
 
 $sql = "insert into dtime(name,dt) values('$name','$dt')";
 $run = mysqli_query($con, $sql);
 
 if($run)
 {
 $_SESSION['status']= "Inserted Into database";
 header('Location: datetime.php');
 }
 else
 {
 $_SESSION[]= "Inserted  NotInto database";
 header('Location: datetime.php');
 
 }
 }
 ?>