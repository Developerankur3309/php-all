

<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>Funda of web</title>
  </head>
  <body>
   <div class="container">
   <div class="row">
   <div class="col-md-12">
   
   <div class="card mt-4">
   
   <div class="card-header">
   <h4>How to Filter or Get data between Two Dates in </h4>
</div>
<div class="card-body">
<form action="#" method="GET">
<div class="row">
<div class="col-md-4">
<div class="form-group">
<label>From Date</label>
<input type="date" name="form_date" value="<?php if(isset($_GET['form_date'])){ echo $_GET['form_date'];} ?>" class="form-control">
</div>
</div>
<div class="col-md-4">
<div class="form-group">
<label>To Date</label>
<input type="date" name="to_date" value="<?php if(isset($_GET['to_date'])){ echo $_GET['to_date'];} ?>" class="form-control">
</div>
</div>
<div class="col-md-4">
<div class="form-group">
<label>Click to Filter</label><br>
<button type="submit" name="filter" class="btn btn-primary">Filter</button>
</div>
</div>
</form>
</div>
</div>
<div class="card mt-2">
<div class="card-body">
<table class="table table-border">
<thead>
<tr>
<th>ID</th>
<th> Name</th>
</tr>
</thead>
<tbody>

<?php
$con = mysqli_connect("localhost","root","","phpbasic");

if(isset($_GET['form_date']) && ($_GET['to_date']))
{
    $form_date = $_GET['form_date'];
    $to_date = $_GET['to_date'];
	
	$query = "SELECT * FROM brands WHERE created_at BETWEEN '$form_date' AND '$to_date'";
    $run = mysqli_query($con, $query);
	
	if(mysqli_num_rows($run) > 0)
	{
	  foreach($run as $row)
	  {
	  ?>
	 
	  <tr>
     <td><?= $row['id']; ?></td>
      <td><?= $row['name']; ?></td>
     </tr>
	 <?php
	  }
	}
	else
	{
	  echo "No Record Found";
	}
	
}
?>

</tbody>
</table>
</div>
</div>
</div>
</div>
</div>
    <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

  </body>
</html>