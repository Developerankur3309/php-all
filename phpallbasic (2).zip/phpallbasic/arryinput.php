<?php

//Array by User Input Method

print "<form method=post>";
for($i=0; $i<5; $i++)
{
 print "<input type=text name=text$i size=5>";
}
print "<input type=submit value= submit />";
print "</form>";

$arr = array();
if(isset($_POST['text0']))
{
for($i=0;$i<5;$i++)
{
 $arr[$i] = $_POST['txt'.$i];
}
print "<pre>";
print_r($arr);
print "</pre>";
}