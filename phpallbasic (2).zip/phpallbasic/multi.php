<?php
session_start();
$con = mysqli_connect("localhost","root","","phpbasic");

if(isset($_POST['save']))
{

// [rinting data in database

/*$brands = $_POST['brands'];
foreach($brands as $item)
{
 echo $item . "<br />";
}
}*/
$brands = $_POST['brands'];
foreach($brands as $item)
{
 
 $query = "INSERT INTO multiplecheck(name) VALUES('$item')";
 $run = mysqli_query($con, $query);
 
}
 if($run)
 {
   $_SESSION['status']="Inserted successfully";
   header("Location: multiplecheck.php");
 }
 else
 {
  $_SESSION['status']=" Not Inserted successfully";
   header("Location: multiplecheck.php");
 }
 }
 ?>