<?php
session_start();

$con = mysqli_connect("localhost","root","","phpbasic");

if(isset($_POST['save']))
{
  $name = $_POST['name'];
  $dob =  date('y-m-d', strtotime($_POST['dob'])); // convertd date formate bcs database chnge formate
  
  $sql = "insert INTO date (name,dob) VALUES('$name','$dob')";
  $run = mysqli_query($con, $sql);
  
   if($run)
   {
   $_SESSION['status']="Inserted Data";
   header("Location: date.php");
   }
   else
   {
   $_SESSION['status']=" Not Inserted Data";
   header("Location: date.php");
   }
  
}

?>
  
