<?php
session_start();
$con = mysqli_connect("localhost","root","","phpbasic"); 

if(isset($_POST['save']))
{
$name = $_POST['name'];
$gender = $_POST['gender'];
 
 $query = "INSERT INTO radio(name,gender) VALUES('$name','$gender')";
 $run = mysqli_query($con, $query);
 
 if($run)
 {
  $_SESSION['status'] = "Inserted Succufully";
  header("Location: radio.php");
 }
 else
 {
 $_SESSION['status']= "Not Inserted";
 header("Location: radio.php");
 }
 }
 
 ?>