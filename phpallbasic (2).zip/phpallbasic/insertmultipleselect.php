<?php
session_start();
?>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>Funda of web</title>
  </head>
  <body>
   <div class="container">
   <div class="row">
   <div class="col-md-12">
   <?php
      if(isset($_SESSION['status']))
	  {
	  ?>
	<div class="alert alert-warning alert-dismissible fade show" role="alert">
  <strong>Hello</strong><?php echo $_SESSION['status'];?>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php
  unset($_SESSION['status']);
   }
   ?>
   <div class="card mt-4">
   
   <div class="card-header">
   <h4> How to Insert  multiple Data  in database
   <a href="javascript:void(0)" class="add-more-form float-end btn btn-primary">Add More</a>
   </h4>
</div>
<div class="card-body">
<form action="insertmultipleselectcode.php" method="POST">
<div class="main-form mt-3 border-bottom">
<div class="row">
<div class="col-md-4 mb-2">
<div class="form-group">
<label for="">Name</label>
<input type="text" name="name[]" class="form-control" required placeholder="Enter Name">
</div>
</div>
<div class="col-md-4 mb-2">
<div class="form-group">
<label for="">Phone</label>
<input type="text" name="phone[]" class="form-control" required placeholder="Enter Number">
</div>
</div>

</div>

<div class="paste-new-from">


</div>
<button type="submit" name="submit" class="btn btn-primary">Save Data</button>
</form>
</div> 
</div>
</div>
</div>
</div>
    <script src="https://code.jquery.com/jquery-3.6.1.js"></script>

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<script>
$(document).ready(function(){

$(document).on('click','.remove-btn' ,function(){
$(this).closest('.main-form').remove();

});
$(document).on('click','.add-more-form',function(){
$('.paste-new-from').append('<div class="main-form mt-3 border-bottom">\
<div class="row">\
<div class="col-md-4 mb-2">\
<div class="form-group">\
<label for="">Name</label>\
<input type="text" name="name[]" class="form-control" required placeholder="Enter Name">\
</div>\
</div>\
<div class="col-md-4 mb-2">\
<div class="form-group">\
<label for="">Phone</label>\
<input type="text" name="phone[]" class="form-control" required placeholder="Enter Number">\
</div>\
</div>\
<div class="col-md-4 mb-2">\
<div class="form-group">\
<br>\
<button type="button" class="remove-btn btn-danger">Remove</button>\
</div>\
</div>\
</div>');

});
});
</script>
  </body>
</html>