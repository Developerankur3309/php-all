<?php
session_start();
$con = mysqli_connect("localhost","root","","phpbasic"); 

if(isset($_POST['save']))
{
$name = $_POST['name'];
$gender = $_POST['gender'];
 
 $query = "INSERT INTO option1(name,gender) VALUES('$name','$gender')";
 $run = mysqli_query($con, $query);
 
 if($run)
 {
  $_SESSION['status'] = "Inserted Succufully";
  header("Location: select.php");
 }
 else
 {
 $_SESSION['status']= "Not Inserted";
 header("Location: select.php");
 }
 }
 
 ?>