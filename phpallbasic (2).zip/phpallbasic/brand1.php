<?php
session_start();
$con = mysqli_connect("localhost","root","","phpbasic");
if(isset($_POST['save']))
{
$name = $_POST['name'];
$query = "INSERT INTO brands(name) VALUES('$name')";
$run = mysqli_query($con, $query);
 

 if($run)
 {
   $_SESSION['status']="Inserted successfully";
   header("Location: brands.php");
 }
 else
 {
  $_SESSION['status']=" Not Inserted successfully";
    header("Location: brands.php");
 }
 }
 ?>