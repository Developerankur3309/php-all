<?php
try
{
 $con=new PDO("mysql:host=localhost;dbname=droplist","root","");
}catch(PDOExection $e)
{
echo $e->getMessage();
}

?>