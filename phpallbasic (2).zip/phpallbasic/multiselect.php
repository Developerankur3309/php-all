<?php
session_start();
$con = mysqli_connect("localhost","root","","phpbasic");

if(isset($_POST['save']))
{

  $brandslist = $_POST['brands'];
  foreach($brandslist as $bitem)
  {
   $queryrun  = "INSERT INTO multiselect(name) VALUES('$bitem')";
   $run = mysqli_query($con, $queryrun);
 
}
 if($run)
 {
   $_SESSION['status']="Inserted successfully";
   header("Location: multpleselect.php");
 }
 else
 {
  $_SESSION['status']=" Not Inserted successfully";
    header("Location: multpleselect.php");
 }
 }
 ?>