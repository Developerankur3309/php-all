<html>
<head>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>

<body>
<div class="container">
<div class="row">  
<div class="col-md-12">
<div class="card mt-3">
<div class="card-header">
<h4> How to Filter or Find or search data using Checkbox</h4>
</div>
</div>
</div>
<!-- Brand list -->
<div class="col-md-3">
<form action="" method="GET">


<div class="card shadow mt-3">
<div class="card-header">
<h5>Filter
<button type="submit" class="btn btn-primary btn-sm float-end">Search</button>
</h5>
</div>
<div class="card-body">
<h6>Brand List</h6>
<hr>
<?php
$conn = mysqli_connect("localhost","root","","phpbasic");
$brand_query="SELECT * FROM brands";
$run = mysqli_query($conn, $brand_query);
if(mysqli_num_rows($run) >0)
{ 
  
  foreach($run as $blist)
  {
   $checked = [];
     if(isset($_GET['brands']))
      {
       $checked = $_GET['brands'];
      }   
  ?>
  <div>
  <input type="checkbox" name="brands[]" value="<?= $blist['id'];?>"  
  <?php if(in_array($blist['id'], $checked)){ echo "checked"; } ?>
  />
  <?= $blist['name'];?>
  </div>
  <?php
  }
}
else
{
 echo "No Brand found";
}
?>

</div>
</div>
</form>
</div>
<!-- Brand items _products -->
<div class="col-md-9">
<div class="card">
<div class="card-body">
<?php

if(isset($_GET['brands']))
{
 $checked = [];
 $checked = $_GET['brands'];
 foreach($checked as $prolist)
 {
 $pro = "SELECT * FROM products WHERE  brand_id	 IN ($prolist)";
$prun = mysqli_query($conn, $pro);
if(mysqli_num_rows($prun) > 0)
{

   foreach($prun as $plist):
   ?>
   <div class="col-md-4">
   <div class="border p-2">
   <h6><?= $plist['name']; ?></h6>
   </div>
   </div>
   <?php
endforeach;
}
else
{
 echo "Data Not Found";
}
 }
 
}
else
{




}
?>
</div>
</div>
</div>
</div>
</div>
</body>
</html>