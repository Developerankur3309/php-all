<?php  
include('conn.php');
$query = "select *from imageupload22";
$run = mysqli_query($con,$query);
?>
<html>
<body>
<table>
<tr>
<th>Name</th>
<th>Email</th>
<th>Image</th>
<th colspan="2">Action</th>
</tr>

<?php
while($row = mysqli_fetch_assoc($run)){
?>
<tr>
<td><?php echo $row['name']; ?></td>
<td><?php echo $row['email']; ?></td>
<td><img src= "<?php echo $row['image']; ?>"></td>
</tr>
<?php

}
?>
</table>
</body>
</html>