<?php
$con = mysqli_connect("localhost","root","","imageupload22") or die("Connection Failed");
?>
