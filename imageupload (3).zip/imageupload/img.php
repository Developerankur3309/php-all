<?php
include('conn.php');

if(isset($_POST['upload']))
  {
     $name = $_POST['name'];
    $email = $_POST['email'];
	
    $image = $_FILES['image']['name'];
    $tmp_name = $_FILES['image']['tmp_name'];
    $folder = "upload/".$image;
     move_uploaded_file($tmp_name, $folder);
    $sql= "insert into upload (name,email,image) values('$name','$email','$folder')";
	
     if(mysqli_query($con, $sql))
    {
	echo "Data Inserted";
	}
	else
	{
	echo "Not Inserted";
	}
	
     
}

?>

<html>
<body>
<br />
<br />
<br />
<br />
<form action="" method="POST" enctype="multipart/form-data">
<input type="text" name="name" placeholder="Enter Your Name"></br>
<input type="text" name="email" placeholder="Enter Your Email"></br>
<input type="file" name="image"></br>
<input type="submit" name="upload" value="upload image">
</form>
</body>
</html>